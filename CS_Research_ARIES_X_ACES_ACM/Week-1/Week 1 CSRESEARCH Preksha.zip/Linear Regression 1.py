import numpy as np

def Linear_regression(X: np.array, y: np.array, lr: float = 0.01, lambda_: float = 0.1, epochs: int = 1000):
    m, n = X.shape
    #initialsing value of weights and bias as 0
    weights = np.zeros(n)
    bias = 0

    for _ in range(epochs):
        y_pred = X @ weights + bias #calc predicted value of y
        error = y_pred - y          #error term in y

        # Gradient with L1 regularization
        dw = (1/m) * (X.T @ error) + lambda_ * np.sign(weights) #X is transposed then matrix mulitplied by the error and lamba ensures the data doesnt overfit 
        db = (1/m) * np.sum(error)

        weights -= lr * dw
        bias -= lr * db

    return weights, bias
